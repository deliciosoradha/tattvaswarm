#!/usr/bin/env python3
"""
Meruprastāra-Dharma: Combinatorial Subsequence Detector for C2 Telemetry
Author: Axel Domingo Padilla Arriaga (@deliciosoradha)
License: Apache-2.0
"""

import math
from typing import List, Dict, Tuple, Optional

# Alphabet of 17 AtomicActions detected at eBPF/XDP boundary
ATOMIC_ACTIONS: Dict[int, str] = {
    1: "probe_syn",
    2: "syn_ack_probe",
    3: "rst_ack_drop",
    4: "ack_push",
    5: "fin_close",
    6: "window_shrink",
    7: "zero_window_probe",
    8: "ja3_variance",
    9: "ja4_ttl_anom",
    10: "payload_entropy_high",
    11: "burst_cadence",
    12: "connect_c2_like",        # SSH bruteforce / witness
    13: "dns_tunnel_or_doh",      # HTTP flood / exfiltration
    14: "kill_security_agent",    # XDP policy drop
    15: "tor_exit_correlation",
    16: "vpn_hop_detected",
    17: "stealth_heartbeat",      # Deterministic timer beacon
}

class MeruprastaraEngine:
    """
    Combinatorial subsequence matcher utilizing binomial stratification
    (Meru Prastāra / Pascal Triangle) over temporal action streams.
    """
    def __init__(self, window_seconds: float = 67.08, tolerance_jitter: float = 0.03):
        self.window_seconds = window_seconds
        self.tolerance_jitter = tolerance_jitter

    @staticmethod
    def calculate_entropy(hex_token: str) -> float:
        """Computes Shannon entropy in bits per character."""
        if not hex_token:
            return 0.0
        prob = [float(hex_token.count(c)) / len(hex_token) for c in set(hex_token)]
        return -sum(p * math.log2(p) for p in prob)

    @staticmethod
    def binomial_weight(n: int, k: int) -> int:
        """Computes binomial coefficient C(n, k) from Meru Prastāra."""
        if k < 0 or k > n:
            return 0
        return math.comb(n, k)

    def classify_ip_role(self, actions: List[int]) -> Tuple[str, float]:
        """
        Classifies an IP behavior into Console, Worker, or Noise.
        Returns (role_name, confidence_score).
        """
        action_set = set(actions)
        has_c2_connect = 12 in action_set
        has_exfil_tunnel = 13 in action_set
        has_policy_drop = 14 in action_set

        if has_c2_connect and has_exfil_tunnel:
            # Dual-channel operator console
            return "console", 0.99
        elif has_c2_connect and not has_exfil_tunnel:
            # Monochromatic brute-force worker
            return "worker", 0.98
        elif has_policy_drop and not has_c2_connect:
            return "scanner_drop", 0.85
        return "unclassified", 0.50

    def match_temporal_cadence(self, timestamps: List[float]) -> Dict[str, float]:
        """
        Evaluates inter-arrival time intervals to detect deterministic beacon timers.
        """
        if len(timestamps) < 2:
            return {"mean_interval": 0.0, "jitter": 0.0, "is_beacon": 0.0}

        diffs = [timestamps[i+1] - timestamps[i] for i in range(len(timestamps)-1)]
        mean_diff = sum(diffs) / len(diffs)
        variance = sum((d - mean_diff) ** 2 for d in diffs) / len(diffs)
        std_dev = math.sqrt(variance)
        jitter = std_dev / mean_diff if mean_diff > 0 else 1.0

        is_beacon = 1.0 if jitter <= self.tolerance_jitter else 0.0
        return {
            "mean_interval_s": round(mean_diff, 2),
            "std_dev_s": round(std_dev, 4),
            "jitter": round(jitter, 4),
            "is_deterministic_beacon": is_beacon
        }

if __name__ == "__main__":
    engine = MeruprastaraEngine()
    print("Meruprastāra-Dharma C2 Combinatorial Engine v0.2 initialized.")
    # Quick sanity check
    sample_entropy = engine.calculate_entropy("86dbd4e076f4205d")
    print(f"Sample Watermark Entropy: {sample_entropy:.2f} bits/char (Expected ~3.2-3.4)")
    assert 3.0 <= sample_entropy <= 3.8, "Entropy check failed"
    role, conf = engine.classify_ip_role([12, 13])
    print(f"IP Role [12, 13]: {role} (Confidence: {conf})")
    assert role == "console", "Role classification check failed"
    print("Sanity checks passed successfully.")
